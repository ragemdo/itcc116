import 'package:flutter/material.dart';

class Profile extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
        children: [
    Padding(
    padding: const EdgeInsets.all(12.0),
    child: Center(
    child: SizedBox(
    child: Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: <Widget>[

    CircleAvatar(
    radius: 80.0,
    backgroundImage: NetworkImage('https://hips.hearstapps.com/hmg-prod/images/elle-fanning-attends-the-2024-met-gala-celebrating-sleeping-news-photo-1715042420.jpg?resize=1200:*', scale: 80),
    ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text('RYAN ANGELO ESCAÑO',
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold
          ),
        ),
      ),

      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text('Bachelor of Science in Information Technology 3rd Year 6th Year Edition',
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold
          ),
        ),
      ),

    ]
    )
    )
    )
    )
    )
        ]
    );
  }
}