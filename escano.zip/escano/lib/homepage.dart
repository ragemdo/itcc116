import 'package:flutter/material.dart';

class HomePage extends StatelessWidget{
@override
  Widget build(BuildContext context){
  return MaterialApp();
  }
}

class HomePageHome extends StatefulWidget{
  @override
  State<HomePageHome> createState() => _HomePageHomeState();
}

class _HomePageHomeState extends State<HomePageHome> {
@override
  Widget build(BuildContext context){
  return Scaffold(
    appBar: AppBar(
      title: Text('Flutter Activities'),
    ),
    drawer: Drawer(),
    bottomNavigationBar: BottomNavigationBar(
        items:[
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard),
            label:'Home'
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label:'Settings'
          ),
        ]
    ),
  );
  }
}