import 'package:escano/profile.dart';
import 'package:escano/settings.dart';
import 'package:escano/users.dart';
import 'package:flutter/material.dart';
import 'dashboard.dart';

class HomePage extends StatelessWidget{
  const HomePage({super.key});

@override
  Widget build(BuildContext context){
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePageHome(),
  );
  }
}

class HomePageHome extends StatefulWidget{
  const HomePageHome({super.key});

  @override
  State<HomePageHome> createState() => _HomePageHomeState();
}

class _HomePageHomeState extends State<HomePageHome> {
  int selectedindex= 0;
  var routes = [Dashboard(),Settings(),Profile(),Users()];

@override
  Widget build(BuildContext context){
  return Scaffold(
    appBar: AppBar(
      title: Text('Flutter Activities'),
    ),
    drawer: Drawer(),
    body: routes[selectedindex],
    bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
      currentIndex: selectedindex,
        onTap:  (index){
        setState(() {
          selectedindex = index;
        });
        },

        items:[
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard,
                  color: Colors.black,),
            label:'Home'
          ),

          BottomNavigationBarItem(
              icon: Icon(Icons.settings,
              color: Colors.black,),
              label:'Settings',

          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.person,
              color: Colors.black,),
            label:'Profile',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list,
              color: Colors.black,),
            label:'Users',

          ),
        ]
    ),
  );
  }
}