import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:escano/homepage.dart';
import 'package:flutter/material.dart';
import 'SignUpScreen.dart';
import 'homepage.dart';

class LoginScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreenHome(),
    );
  }
}

class LoginScreenHome extends StatefulWidget{
  @override
  State<LoginScreenHome> createState() => _LoginScreenHomeState();
}

class _LoginScreenHomeState extends State<LoginScreenHome> {
  var hidePassword = true;
  var usernameController = TextEditingController();
  var passwordController = TextEditingController();
  var staticUsername ="admin";
  var staticPassword ="123";

  void maskedUnmaskedPassword(){
    if(hidePassword == true) {
      setState(() {
        hidePassword = false;
      });
    } else {
      setState(() {
        hidePassword = true;
      });
    }
  }

  void validateInput() {
    var username = usernameController.text;
    var password = passwordController.text;
    if(username.isEmpty) {

      AwesomeDialog(
          context: context,
          dialogType: DialogType.error,
        title: 'Error',
        desc: 'Username Is Required',
        width: MediaQuery.of(context).size.width/2,
          btnOkOnPress: (){}
      ).show();

      print("Username is empty!");
    } else if(password.isEmpty) {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.error,
          title: 'Error',
          desc: 'Password Is Required',
          width: MediaQuery.of(context).size.width/2,
          btnOkOnPress: (){}
      ).show();

      print("Password is empty!");
    } else {
    validateUsernameAndPassword(username, password);
      print("The value of Username is $username and the password is $password");
    }
  }

  void validateUsernameAndPassword(String username, String password){
    if(staticUsername != username){
      AwesomeDialog(
        context: context,
        title:'Error',
        desc: 'Invalid Username provided!',
          width: MediaQuery.of(context).size.width/2,
          btnOkOnPress: (){}
    ).show();
    }

    else if (staticPassword != password){ AwesomeDialog(
        context: context,
        title:'Error',
        desc: 'Invalid Password provided!',
        width: MediaQuery.of(context).size.width/2,
        btnOkOnPress: (){}
    ).show();
    }

    else{

      //Login to Dashboard
      Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context)=>HomePage()));
    }

  }

  @override
  Widget build(BuildContext context){return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Center(
              child: SizedBox(
                height: 600,
                width: 300,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        CircleAvatar(
                          radius: 80.0,
                          backgroundImage: NetworkImage('https://hips.hearstapps.com/hmg-prod/images/elle-fanning-attends-the-2024-met-gala-celebrating-sleeping-news-photo-1715042420.jpg?resize=1200:*', scale: 80),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text('Please Login',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: TextField(
                            controller: usernameController,
                            decoration: InputDecoration(
                                label: Text('Username'),
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.person_outline)
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            controller: passwordController,
                            obscureText: hidePassword,
                            decoration: InputDecoration(
                                label: Text('Password'),
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.password),
                                suffixIcon: IconButton(
                                  onPressed: (){
                                    maskedUnmaskedPassword();
                                  },
                                  icon: Icon(Icons.remove_red_eye_outlined),
                                )
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: SizedBox(
                            height: 40,
                            width: MediaQuery.of(context).size.width,
                            child: ElevatedButton(
                                style: ButtonStyle(
                                    backgroundColor: WidgetStatePropertyAll(Colors.blue)
                                ),
                                onPressed: (){
                                  validateInput();
                                }, child: Text('LOGIN', style: TextStyle(color: Colors.white),)
                            ),
                          ),
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('No Account?'),
                            TextButton(onPressed: (){
                              Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context)=> SignupScreen()));
                            }, child: Text('SIGN-UP')
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}